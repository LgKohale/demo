package com.cg.trg.BddMaven;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Maven {

	@Given("^enter username and pass$")
	public void enter_username_and_pass() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("BDD");
	    throw new PendingException();
	}

	@Then("^navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}
}


function validate() {
	var x= document.forms["form1"]["userName"].value;
	if(x=="") {
		alert("please fill username..");
		return false;
	}
	var city= document.forms["form1"]["city"].value;
	if(city==""){
		alert("please enter city name");
		return false;
	}
	var pass= document.forms["form1"]["password"].value;
	if(pass==""){
		alert("enter password..");
		return false;
	}
	
	if(!(document.getElementById('male').checked) && !(document.getElementById('female').checked)){
		alert("Please select Gender: Male or Female");
		return false;
	}
	else if((document.getElementById('male').checked) && (document.getElementById('female').checked)){
		alert("Select only one gender button");
		return false;
	}
	if(!(document.getElementById('eng').checked) && !(document.getElementById('tel').checked) &&
					!(document.getElementById('tam').checked)){
						alert("Select atleast one Language..");
						return false;
					}
	
	var mob= document.forms["form1"]["mobile"].value;
	if(mob==""){
		alert("Please enter mobile number..");
		return false;
	}
	
	var mail=document.forms["form1"]["email"].value;
	if(mail==""){
		alert("Enter email id..");
		return false;
	}
	
	var mob1= document.forms["form1"]["mobile"].value;
	var len= mob1.length;
	if(len > 10){
		alert("Enter correct mobile number..");
		return false;
		
	}
	
}
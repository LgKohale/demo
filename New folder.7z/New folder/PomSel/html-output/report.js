$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cg/trg/pom/validform.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Latika"
    }
  ],
  "line": 3,
  "name": "validating form",
  "description": "",
  "id": "validating-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Null username field",
  "description": "",
  "id": "validating-form;null-username-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "check for username",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "empty value is enterd in name text box",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_username()"
});
formatter.result({
  "duration": 5067179467,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.empty_value_is_enterd_in_name_text_box()"
});
formatter.result({
  "duration": 620676910,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.print_error_message()"
});
formatter.result({
  "duration": 3159410992,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Null city field",
  "description": "",
  "id": "validating-form;null-city-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "check for city name",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "empty city name is entered",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_city_name()"
});
formatter.result({
  "duration": 2869797401,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.empty_city_name_is_entered()"
});
formatter.result({
  "duration": 618832977,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5084242515,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "Null password field",
  "description": "",
  "id": "validating-form;null-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "check for password",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "empty password is entered",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "print invalid message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_password()"
});
formatter.result({
  "duration": 2910284757,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.empty_password_is_entered()"
});
formatter.result({
  "duration": 576481587,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.print_invalid_message()"
});
formatter.result({
  "duration": 5086303453,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "radio button not clicked",
  "description": "",
  "id": "validating-form;radio-button-not-clicked",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "check for radio button",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "either button is not clicked",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "error message displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_radio_button()"
});
formatter.result({
  "duration": 2850615984,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.either_button_is_not_clicked()"
});
formatter.result({
  "duration": 530687641,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message_displayed()"
});
formatter.result({
  "duration": 5072773620,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "checkbox validation",
  "description": "",
  "id": "validating-form;checkbox-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "check for checkbox",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "no checkbox is selected",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "error messages",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_checkbox()"
});
formatter.result({
  "duration": 2762037048,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.no_checkbox_is_selected()"
});
formatter.result({
  "duration": 546328461,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_messages()"
});
formatter.result({
  "duration": 3101272745,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "check for email",
  "description": "",
  "id": "validating-form;check-for-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "check for email id",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "no email id entered",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_email_id()"
});
formatter.result({
  "duration": 2799065440,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.no_email_id_entered()"
});
formatter.result({
  "duration": 478038120,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3221043892,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "no mobile number",
  "description": "",
  "id": "validating-form;no-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "check for mobile number",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "no mobile number entered",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "prompt error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.check_for_mobile_number()"
});
formatter.result({
  "duration": 2885687633,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.no_mobile_number_entered()"
});
formatter.result({
  "duration": 537721251,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.prompt_error_message()"
});
formatter.result({
  "duration": 5114593367,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "wrong mobile number",
  "description": "",
  "id": "validating-form;wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "enter all fields",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "enter wrong mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "prompt invalid",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.enter_all_fields()"
});
formatter.result({
  "duration": 2927209150,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.enter_wrong_mobile_number()"
});
formatter.result({
  "duration": 666050792,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.prompt_invalid()"
});
formatter.result({
  "duration": 13909286,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no alert open\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T520\u0027, ip: \u002710.219.34.236\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.38.552522 (437e6fbedfa876..., userDataDir: C:\\Users\\lkohale\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: b8f2ec89327d0f9c4f16c3f986a9cb7d\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cg.trg.pom.StepDefinition.prompt_invalid(StepDefinition.java:261)\r\n\tat ✽.Then prompt invalid(com/cg/trg/pom/validform.feature:46)\r\n",
  "status": "failed"
});
});
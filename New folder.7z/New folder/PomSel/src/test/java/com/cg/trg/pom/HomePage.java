package com.cg.trg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	private WebDriver wdriver;
	
	public HomePage(WebDriver driver) {
		this.wdriver= driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement username;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"male\"]")
	@CacheLookup
	WebElement mgender;

	@FindBy(xpath="//*[@id=\"female\"]")
	@CacheLookup
	WebElement fgender;
	
    @FindBy(xpath="/html/body/center/form/input[7]")
	@CacheLookup
	WebElement english;
	
	@FindBy(xpath="/html/body/center/form/input[8]")
	@CacheLookup
	WebElement telugu;
	
	@FindBy(xpath="/html/body/center/form/input[9]")
	@CacheLookup
	WebElement tamil;
	@FindBy(xpath="/html/body/center/form/input[12]")
	@CacheLookup
	WebElement email;

	@FindBy(name="mobile")
	@CacheLookup
	WebElement mobile;
	
	/*@FindBy(xpath="/html/body/center/form/select")
	@CacheLookup
	WebElement country;
	
	@FindBy(xpath="/html/body/center/form/input[11]")
	@CacheLookup
	WebElement my_number;
	
	@FindBy(name="saves data")
	@CacheLookup
	WebElement submit;
	
	@FindBy(xpath="/html/body/center/form/input[16]")
	@CacheLookup
	WebElement clear;
	
	@FindBy(xpath="/html/body/center/form/input[17]")
	@CacheLookup
	WebElement submit1;*/
	

	@FindBy(xpath="/html/body/center/form/button")
	@CacheLookup
	WebElement submit;
	
	

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String name) {
		username.sendKeys(name);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city1) {
		city.sendKeys(city1);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String pass) {
		password.sendKeys(pass);
	}

	public WebElement getsubmit() {
		return submit;
	}

	public void setsubmit() {
		submit.click();
	}

	public WebElement getMgender() {
		return mgender;
	}

	public void setMgender() {
		mgender.click();
	}

	public WebElement getFgender() {
		return fgender;
	}

	public void setFgender() {
		fgender.click();
	}

	public WebElement getEnglish() {
		return english;
	}

	public void setEnglish() {
		english.click();
	}

	public WebElement getTelugu() {
		return telugu;
	}

	public void setTelugu() {
		telugu.click();
	}

	public WebElement getTamil() {
		return tamil;
	}

	public void setTamil() {
		tamil.click();
	}
	
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String mail) {
		email.sendKeys(mail);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mob) {
		mobile.sendKeys(mob);
	}
	
}

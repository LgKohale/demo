package com.cg.trg.pom;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	private HomePage home;
	private WebDriver wd;
	
	//empty username string
	@Given("^check for username$")
	public void check_for_username() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	
	@When("^empty value is enterd in name text box$")
	public void empty_value_is_enterd_in_name_text_box() throws Throwable {
	    home.setUsername("");
	    home.setCity("Pune");
	    home.setPassword("pune123");
	    home.setFgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	
	@Then("^print error message$")
	public void print_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}
//----------------------------------------------------------------------------------------
	
	//empty city field
	@Given("^check for city name$")
	public void check_for_city_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^empty city name is entered$")
	public void empty_city_name_is_entered() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("");
	    home.setPassword("pune123");
	    home.setFgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	@Then("^error message$")
	public void error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}
	
//----------------------------------------------------------------------------------------------------------
	
	//empty password field
	@Given("^check for password$")
	public void check_for_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^empty password is entered$")
	public void empty_password_is_entered() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("Pune");
	    home.setPassword("");
	    home.setFgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	@Then("^print invalid message$")
	public void print_invalid_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}
	
	//-----------------------------------------------------------------------------------------
	
	
//no radio button clicked
	@Given("^check for radio button$")
	public void check_for_radio_button() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^either button is not clicked$")
	public void either_button_is_not_clicked() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("Pune");
	    home.setPassword("pune123");
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	@Then("^error message displayed$")
	public void error_message_displayed() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}
//-----------------------------------------------------------------------------------------------------------
	
	
//no checkbox selected
	@Given("^check for checkbox$")
	public void check_for_checkbox() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^no checkbox is selected$")
	public void no_checkbox_is_selected() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("Pune");
	    home.setPassword("pune123");
	    home.setMgender();
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}
	
	@Then("^error messages$")
	public void error_messages() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}
//---------------------------------------------------------------------------------------------------
	
	//empty email field
	@Given("^check for email id$")
	public void check_for_email_id() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^no email id entered$")
	public void no_email_id_entered() throws Throwable {
		home.setUsername("Prachi");
		home.setCity("Mumbai");
	    home.setPassword("mumbai");
	    home.setFgender();
	    home.setEnglish();
	    home.setMobile("1466677687");
	    home.setsubmit();
	}
	//-----------------------------------------------------------------------------------------------------
	
	
	//empty mobile number field
	@Given("^check for mobile number$")
	public void check_for_mobile_number() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^no mobile number entered$")
	public void no_mobile_number_entered() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("davidmum");
	    home.setMgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("ss@view.org");
	    home.setsubmit();
	}

	@Then("^prompt error message$")
	public void prompt_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}
	//-----------------------------------------------------------------------------------------------------------

	//wrong mobile number
	@Given("^enter all fields$")
	public void enter_all_fields() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}

	@When("^enter wrong mobile number$")
	public void enter_wrong_mobile_number() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("davidmum");
	    home.setMgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("ss@view.org");
	    home.setMobile("8945612352555");
	    home.setsubmit();
	}

	@Then("^prompt invalid$")
	public void prompt_invalid() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}


}

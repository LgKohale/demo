package com.capgemini.flp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="merchant_login")
public class Merchant {

	@Id
	@Column(name="email_Id")
	private String emailId;
	private String name;
	private String password;
	private Long phoneNumber;
	@Column(name="Organization_name")
	private String organization;
	private String address;
	
	public Merchant() {
		
	}

	public Merchant(String emailId, String name, String password,
			Long phoneNumber, String organization, String address) {
		super();
		this.emailId = emailId;
		this.name = name;
		this.password = password;
		this.phoneNumber = phoneNumber;
		this.organization = organization;
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}





package com.capgemini.flp.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.ProductException;
import com.capgemini.flp.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	IProductService productService;
	
	@RequestMapping(value="/cpage", method=RequestMethod.GET)
	public ModelAndView customerPage() {
		Customer customer=new Customer();
			return new ModelAndView("CustomerPage","customer",customer);
	} 
	
	@RequestMapping(value="/mpage", method=RequestMethod.GET)
	public ModelAndView MerchantPage() {
		Merchant merchant= new Merchant();
			return new ModelAndView("MerchantPage","merchant",merchant);
	} 
	
	
	@RequestMapping(value="/cprofile", method=RequestMethod.GET)
	public ModelAndView customerForm() {
		Customer customer=new Customer();
			return new ModelAndView("CustomerProfile","customer",customer);
	} 
	
	@RequestMapping(value="/mprofile", method=RequestMethod.GET)
	public ModelAndView merchantForm() {
		Merchant merchant= new Merchant();
			return new ModelAndView("MerchantProfile","merchant",merchant);
	} 
	
	@RequestMapping(value="/editp", method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute(value="customer")Customer c){
		try{
			String status=productService.updateCustomer(c);
			return new ModelAndView("Status","message",status);
		}catch(ProductException e){
			return new ModelAndView("Status","message",e.getMessage());
		}
	}

	@RequestMapping(value="/editm", method=RequestMethod.POST)
	public ModelAndView updateMerchant(@ModelAttribute(value="merchant")Merchant m){
		try{
			String status=productService.updateMerchant(m);
			return new ModelAndView("Status1","message",status);
		}catch(ProductException e){
			return new ModelAndView("Status1","message",e.getMessage());
		}
	}
	
	
	@RequestMapping(value={"/","/homepage"})
	public ModelAndView showHomePage(){
		
		ModelAndView mv=new ModelAndView("homepage");
		try {
			List<Admin> products=productService.getProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/category")
	public ModelAndView  category(){
		ModelAndView mv=new ModelAndView("category");
		try {
			List<Admin> products=productService.getProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping(value="/products",method=RequestMethod.GET)
	public ModelAndView  products(@RequestParam(value="name")String name){
		ModelAndView mv=new ModelAndView("products");
		try {
			List<Admin> products=productService.getProductsBasedOnCategory(name);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
}

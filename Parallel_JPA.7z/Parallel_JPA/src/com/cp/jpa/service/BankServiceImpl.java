package com.cp.jpa.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.jpa.dao.BankDAO;
import com.cg.jpa.dao.BankDaoImpl;
import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;

public class BankServiceImpl implements BankService {

	private BankDAO dao= new BankDaoImpl();
	private BankDaoImpl dao1= new BankDaoImpl();
	@Override
	public int addCustomer(Bank bean) throws BankException {
		// TODO Auto-generated method stub
		return dao.addCustomer(bean);
	}

	@Override
	public double showBalance(int acc, int apin) throws BankException {
		// TODO Auto-generated method stub
		return dao.showBalance(acc, apin);
	}

	@Override
	public double withdrawAmount(int acc2, int apin2, double withdraw)throws BankException {
		// TODO Auto-generated method stub
		 return dao.withdrawAmount(acc2, apin2, withdraw);
	}

	@Override
	public double FundTransfer(int acc3, int apin3, int acc4, double amount)throws BankException {
		// TODO Auto-generated method stub
		return dao.FundTransfer(acc3, apin3, acc4, amount);
	}

	@Override
	public double depositAmount(int acc1, int apin1, double deposit)throws BankException {
		// TODO Auto-generated method stub
		return dao.depositAmount(acc1, apin1, deposit);
	}

	@Override
	public List<Transaction> printTransaction(int account) throws BankException {
		return dao.printTransaction(account);
		
		
	}
	
	
	public Boolean validAccount(int acc4, int pin4) throws BankException {
		return dao1.validAccount(acc4, pin4);
		
	}

	public Boolean valida(int acc5) throws BankException {
		// TODO Auto-generated method stub
		return dao1.valida(acc5);
	}

	public boolean validName(String vname) {
		boolean flag = false;
		flag = vname.matches("[A-Z][a-zA-Z]*");

		return flag;
	}

	public boolean validAdhar(String idProof) {
		Pattern aadharPattern = Pattern.compile("\\d[1-9]{11}");
		boolean isValidAadhar = aadharPattern.matcher(idProof).matches();
		return isValidAadhar;
	}

	public boolean validMobileaNo(String custMobNo) {
		Pattern p = Pattern.compile("[7-9][0-9]{9}");

		Matcher m = p.matcher(custMobNo);
		Boolean b = (m.find() && m.group().equals(custMobNo));
		if (b) {
			return b;
		} else {
			return false;
		}
	}

	public boolean validAge(int custAge) {
		if (custAge > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean validEmail(String emailid) {
		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		String email1 = emailid;
		Boolean b = email1.matches(EMAIL_REGEX);
		if (b) {
			return b;
		} else {
			return false;
		}
	}

	

}

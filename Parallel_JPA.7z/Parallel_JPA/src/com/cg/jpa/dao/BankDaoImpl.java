package com.cg.jpa.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;
import com.cg.jpa.utility.JPAUtil;

public class BankDaoImpl implements BankDAO {

	private EntityManager entityManager= null;
	Scanner sc= new Scanner(System.in);
	Transaction tran= null;
	DateFormat dateF= new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date;
	
	@Override
	public int addCustomer(Bank bean) throws BankException {
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();

			entityManager.persist(bean);
			entityManager.getTransaction().commit();
		}catch(PersistenceException e){
			//e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}
		return bean.getAccountNo();
	}

	@Override
	public double showBalance(int acc, int apin) throws BankException{
		Bank b1;
		double balance=0.0;
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			 b1= entityManager.find(Bank.class, acc);
			boolean valid= validateAccount(b1, acc, apin);
			if(valid){
				balance= b1.getBalance();
				//System.out.println("Your account balance is: "+b1.getBalance());
			}else{
				System.out.println("Invalid Credentials..");
			}
			entityManager.getTransaction().commit();
		}catch(PersistenceException e) {
			//e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}	
		return balance;
	}
	

	@Override
	public double depositAmount(int acc1, int apin1, double deposit)throws BankException {
		double balance=0.0;
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Bank b1= entityManager.find(Bank.class, acc1);
			balance= deposit + b1.getBalance();
			b1.setBalance(balance);
			entityManager.merge(b1);
			
			date=new Date();
			tran= new Transaction();
			tran.setAccountNo(acc1);
			tran.setTransaction("Deposited: "+deposit+" on: "+dateF.format(date));
			entityManager.persist(tran);
			//System.out.println(b1);
			entityManager.getTransaction().commit();
			
		}catch(PersistenceException e) {
			//e.printStackTrace();
			
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}
		return balance;
	}

	@Override
	public double withdrawAmount(int acc2, int apin2, double withdraw) throws BankException {
		double balance=0.0;
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Bank b1= entityManager.find(Bank.class, acc2);
			if(b1.getBalance() < withdraw){
				System.out.println("Insufficeient amount in account: "+b1.getBalance());
			}else{
				balance= b1.getBalance() - withdraw;
				b1.setBalance(balance);
				entityManager.merge(b1);
				date=new Date();
				tran= new Transaction();
				tran.setAccountNo(acc2);
				tran.setTransaction("Withdraw: "+withdraw+" on: "+dateF.format(date));
				entityManager.persist(tran);
			}
			entityManager.getTransaction().commit();
		
		}catch(PersistenceException e){
			//e.printStackTrace();
			
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}
		return balance;
	}

	@Override
	public double FundTransfer(int acc3, int apin3, int acc4, double amount) throws BankException {
		double bal2;
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Bank b1= entityManager.find(Bank.class, acc3);
			if(b1.getBalance() < amount){
				System.out.println("Insufficient amount in account: "+b1.getAccountNo());
			}else{
				double bal1= b1.getBalance() - amount;
				b1.setBalance(bal1);
				entityManager.merge(b1);
				date=new Date();
				tran= new Transaction();
				tran.setAccountNo(acc3);
				tran.setTransaction("Fund Transfered : "+amount+" on: "+dateF.format(date));
				entityManager.persist(tran);
			}
				
			Bank b2= entityManager.find(Bank.class, acc4);
			 bal2= b2.getBalance() + amount;
			b2.setBalance(bal2);
			entityManager.merge(b2);
			date=new Date();
			tran= new Transaction();
			tran.setAccountNo(acc4);
			tran.setTransaction("Fund Received: "+amount+" on: "+dateF.format(date));
			entityManager.persist(tran);
			entityManager.getTransaction().commit();	
		}catch(PersistenceException e){
			//e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}
		return bal2;
	}


	private boolean validateAccount(Bank b1, int acc, int apin) {
		boolean flag= false;
		if((b1.getAccountNo()== acc) &&(b1.getAccPin()==apin)){
			flag= true;
			return flag;
		}else{
			return false;
		}
	}

	public Boolean validAccount(int acc4, int pin4) throws BankException {
		boolean flag=false;
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Bank bank=entityManager.find(Bank.class, acc4);
			if((bank.getAccountNo()==acc4) && (bank.getAccPin()==pin4)){
				flag= true;
				return flag;
			}else{
				return flag;
			}
		}catch(PersistenceException e){
			//e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}
	}

	public Boolean valida(int acc5) throws BankException {
		boolean flag=false;
		try{
			entityManager= JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Bank bank=entityManager.find(Bank.class, acc5);
			if(bank.getAccountNo()==acc5 ){
				flag= true;
				return flag;
			}else{
				return flag;
			}
		}catch(PersistenceException e){
			//e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}
		
	}

	@Override
	public List<Transaction> printTransaction(int account) throws BankException {
		try{
			entityManager=JPAUtil.getEntityManager();
		javax.persistence.Query query = entityManager.createQuery("from Transaction where accountNo=?");
		query.setParameter(1, account);
		List<Transaction> empList=query.getResultList();
		return empList;
		
		}catch(PersistenceException e) {
			//e.printStackTrace();
			throw new BankException(e.getMessage());
		}finally{
			entityManager.close();
		}		
				
				
	}
					

}

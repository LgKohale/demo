package com.cg.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction")

public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int serialno;
	private int accountNo;
	private String transaction;
	
	
	public int getSerialno() {
		return serialno;
	}

	public void setSerialno(int serialno) {
		this.serialno = serialno;
	}

	

	public Transaction() {
		
	}
	
	public Transaction(int accountNo, String transaction) {
		super();
		this.accountNo = accountNo;
		this.transaction = transaction;
	}

	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	
	
	@Override
	public String toString() {
		return "Transaction [accountNo=" + accountNo + ", transaction="
				+ transaction + "]";
	}
	
	

}

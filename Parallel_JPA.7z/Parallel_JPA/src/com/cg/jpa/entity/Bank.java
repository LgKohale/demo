package com.cg.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.internal.NotNull;



@Entity
@Table(name = "bank")
public class Bank {
	@NotNull
	private String custName;
	private String address;
	@NotNull
	private String emailid;
	@NotNull
	private String idProof;
	@NotNull
	private String custMobNo;
	@NotNull
	private int custAge;
	@Id
	private int accountNo;
	@NotNull
	private int accPin;
	private double balance;
	
	
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getIdProof() {
		return idProof;
	}
	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}
	public String getCustMobNo() {
		return custMobNo;
	}
	public void setCustMobNo(String custMobNo) {
		this.custMobNo = custMobNo;
	}
	public int getCustAge() {
		return custAge;
	}
	public void setCustAge(int custAge) {
		this.custAge = custAge;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAccPin() {
		return accPin;
	}
	public void setAccPin(int accPin) {
		this.accPin = accPin;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
		
	@Override
	public String toString() {
		return "Bank [custName=" + custName + ", address=" + address+"\n"
				+ ", emailid=" + emailid + ", idProof=" + idProof+"\n"
				+ ", custMobNo=" + custMobNo + ", custAge=" + custAge+"\n"
				+ ", accountNo=" + accountNo + ", accPin=" + accPin+"\n"
				+ ", balance=" + balance + "]";
	}
	
	
	
	

}

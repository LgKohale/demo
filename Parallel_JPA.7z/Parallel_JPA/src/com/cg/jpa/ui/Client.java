package com.cg.jpa.ui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;
import com.cp.jpa.service.BankService;
import com.cp.jpa.service.BankServiceImpl;

public class Client {
	private static BankService service= new BankServiceImpl();
	private static Scanner sc= new Scanner(System.in);
	private static BankServiceImpl serv= new BankServiceImpl();

	public static void main(String[] args) throws BankException {
		do{
			System.out.println("===============================");
			System.out.println("===========Welcome=============");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit Amount");
			System.out.println("4.Withdraw Amount");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			System.out.println("===============================");
			System.out.println("Enter your Choice");
			Scanner scanner=new Scanner(System.in);
			int choice = sc.nextInt();
			
			switch(choice){
			case 1:
				try {
				Bank bank= new Bank();
				getCustomerDetails(bank);
				//service.validation(bank);
				int cAccount=addCustomer(bank);
				System.out.println("------------------------------------");
				System.out.println("Your account no. is :"+cAccount);
				System.out.println("Account pin is :"+bank.getAccPin());
				
				System.out.println(bank);
				System.out.println("===============================");
				System.out.println("===============================");
				}
				catch(InputMismatchException e)
				{
					System.err.println("The Input is mismatched");
				//	throw new BankException(e.getMessage());
				}
				catch(NullPointerException e){
					System.err.println("Error: Null returned");
				}
				break;
				
			case 2:	
				try{
				System.out.println("Enter Account number: ");
				int acc1= scanner.nextInt();
				System.out.println("Enter Account pin: ");
				int pin1= scanner.nextInt();
				double balance=service.showBalance(acc1, pin1);
				System.out.println("------------------------------------");
				System.out.println("Your Account Balance is: "+balance);
				}catch(BankException e){
					System.out.println("This is an Exception:"+e.getStatus());
				}
				catch(InputMismatchException e)
				{
					System.err.println("The Input is mismatched");
				//	throw new BankException(e.getMessage());
				}
				catch(NullPointerException e){
					System.err.println("Error: Null returned");
				}
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 3:
				try{
				System.out.println("Enter Account number: ");
				int acc2= scanner.nextInt();
				System.out.println("Enter Account pin: ");
				int pin2= scanner.nextInt();
				Boolean valid= serv.validAccount(acc2, pin2);
				if(valid){
					System.out.println("Enter the amount to deposit: ");
					double deposit= scanner.nextDouble();
					if(deposit<=0){
						do{
							System.out.println("Enter valid deposit amount: ");
							deposit=scanner.nextDouble();
						}while(!(deposit>0));
					}
					double accBal=service.depositAmount(acc2, pin2,deposit);
					System.out.println("------------------------------------");
					System.out.println("Your Account balance is: "+accBal);
				}else{
					System.out.println("Invalid Account Credentials..");
				}
				
				System.out.println("===============================");
				System.out.println("===============================");
				}catch(BankException e){
					System.out.println("This is an Exception:"+e.getMessage());
				}catch(InputMismatchException e1)
				{
					System.err.println("The Input is mismatched. Enter correct ");
					
				}catch(NullPointerException e){
					System.err.println("Error: Null returned");
				}
				break;
				
			case 4:
				try{
				System.out.println("Enter Account number: ");
				int acc3= scanner.nextInt();
				System.out.println("Enter Account pin: ");
				int pin3= scanner.nextInt();
				Boolean valid= serv.validAccount(acc3, pin3);
				if(valid){
					System.out.println("Enter the amount to withdraw: ");
					double withdraw= scanner.nextDouble();
					if(withdraw<=0){
						do{
							System.out.println("Enter valid withdraw amount: ");
							withdraw=scanner.nextDouble();
						}while(!(withdraw>0));
						
					}
					double accbal= service.withdrawAmount(acc3, pin3, withdraw);
					System.out.println("------------------------------------");
					System.out.println("Your Account balance is: "+accbal);
				}else{
					System.out.println("Invalid Account Credentials..");
				}
				}catch(BankException e){
					System.out.println("This is an Exception:"+e.getMessage());
				}catch(InputMismatchException e)
				{
					System.err.println("The Input is mismatched");
					//throw new BankException(e.getMessage());
				}catch(NullPointerException e){
					System.err.println("Error: Null returned");
				}
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 5:
				try{
				System.out.println("Enter sender's Account number: ");
				int acc4=scanner.nextInt();
				System.out.println("Enter Account pin: ");
				int pin4=scanner.nextInt();
				
				Boolean valid1= serv.validAccount(acc4, pin4);
				if(valid1){
					System.out.println("Enter receiver's Account number: ");
					int acc5= scanner.nextInt();
					Boolean valid2= serv.valida(acc5);
					if(valid2){
						System.out.println("Enter the amount to transfer: ");
						double amount=scanner.nextDouble();
						if(amount<=0){
							do{
								System.out.println("Enter valid transfer amount: ");
								amount=scanner.nextDouble();
							}while(!(amount>0));
							
						}
						double balf=service.FundTransfer(acc4, pin4, acc5, amount);
						System.out.println("------------------------------------");
						System.out.println("Amount"+amount+" is transfered successfully");
					}else{
						System.out.println("Account dosen't Exist: "+acc5);
					}
				}else{
					System.out.println("Account dosen't Exist: "+acc4);
				}
				}catch(BankException e){
					System.out.println("This is an Exception:"+e.getMessage());
				}catch(InputMismatchException e)
				{
					System.err.println("The Input is mismatched");
				}catch(NullPointerException e){
					System.err.println("Error: Null returned");
				}
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 6:
				try{
				System.out.println("Enter the Account number: ");
				int account=scanner.nextInt();
				List<Transaction> list= service.printTransaction(account);
				showDetails(list);
				
				}catch(BankException e){
					System.out.println("This is an Exception:"+e.getMessage());
				}catch(InputMismatchException e)
				{
					System.err.println("The Input is mismatched");
					//throw new BankException(e.getMessage());
					
				}catch(NullPointerException e){
					System.err.println("Error: Null returned");
				}
				System.out.println("===============================");
				System.out.println("===============================");
				
				break;
				
			case 7:
				System.exit(0);
				
			default:
				System.out.println("Enter choice between [1-7]");
				break;
			}
			
		}while(true); 
	}

	private static void showDetails(List<Transaction> list) {
		Iterator<Transaction> it= list.iterator();
		System.out.println("-------------------------------");
		System.out.println("-------------------------------");
		while(it.hasNext()){
			
			System.out.println(it.next());
			
		}
		System.out.println("===============================");
		System.out.println("===============================");
	}

	private static int addCustomer(Bank bank) {
		int create=0;
		try {
			create=service.addCustomer(bank);
			
		} catch (BankException e) {
			e.printStackTrace();
		}
		return create;
	}

	private static void getCustomerDetails(Bank bank) {
		System.out.println("Enter Customer name: ");
		String custName=sc.next();
		boolean validname=serv.validName(custName);
		String vname;
		boolean validn;
		if(!validname){
			do{
				System.out.println("Enter name with Init-caps(ex:Tom): ");
				System.out.println("Enter your Name: ");
				vname= sc.next();
				validn = serv.validName(vname);
			}while(!validn);
			bank.setCustName(vname);
		}
		else
			bank.setCustName(custName);
		
		
		System.out.println("Enter your Address: ");
		bank.setAddress(sc.next());
		
		System.out.println("Enter AAdhar Card number: ");
		String idProof = sc.next();
		boolean validac=serv.validAdhar(idProof);
		boolean validaa;
		String proof;
		if(!validac){
			do{
				System.out.println("Enter 12 digit Aadhar card number: ");
				System.out.println("Enter the Aadhar number " );
				proof=sc.next();
				validaa= serv.validAdhar(proof);
			}while(!validaa);
			bank.setIdProof(proof);
		}else
			bank.setIdProof(idProof);
		
		
		System.out.println("Enter mobile number: ");
		String custMobNo = sc.next();
		boolean validm= serv.validMobileaNo(custMobNo);
		boolean Validm;
		String mob;
		if(!validm){
			do{
				System.out.println("Enter correct 10 digit mobile number: ");
				mob=sc.next();
				Validm= serv.validMobileaNo(mob);
			}while(!Validm);
			bank.setCustMobNo(mob);
		}else
			bank.setCustMobNo(custMobNo);
		
		
		System.out.println("Enter customer age: ");
		int custAge = sc.nextInt();
		boolean validage= serv.validAge(custAge);
		boolean Validage;
		int age;
		if(!validage){
			do{
				System.out.println("Enter valid age :");
				age=sc.nextInt();
				Validage=serv.validAge(age);
			}while(!Validage);
			bank.setCustAge(age);
		}else
			bank.setCustAge(custAge);
		
		
		System.out.println("Enter email id: ");
		String emailid = sc.next();
		boolean isvalid = serv.validEmail(emailid);
		boolean validid;
		String emailid1;
		if (!isvalid) {
			do {
				System.out.println("Type correct email Id");
				System.out.println("Enter your email id:");
				emailid1 = sc.next();
				validid = serv.validEmail(emailid1);

			} while (!validid);
			bank.setEmailid(emailid1);
		}else
			bank.setEmailid(emailid);
		bank.setBalance(0.0);
		Random rd1 = new Random();
		int accountNo = 1000000 + rd1.nextInt(900000);
		bank.setAccountNo(accountNo);
		Random rd2 = new Random();
		int accPin = 1000 + rd2.nextInt(9000);
		bank.setAccPin(accPin);	
		System.out.println("Enter the minimum balance you want to keep: ");
		bank.setBalance(sc.nextDouble());
		
	}

}

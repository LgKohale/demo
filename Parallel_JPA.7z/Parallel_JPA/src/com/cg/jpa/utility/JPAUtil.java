package com.cg.jpa.utility;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class JPAUtil {
	
	public static EntityManager getEntityManager() {
		/*if(entityManager==null || !entityManager.isOpen()) {
			entityManager = factory.createEntityManager();
		}
		return entityManager;*/
		return Persistence.createEntityManagerFactory("Parallel_JPA").createEntityManager();
	}

}

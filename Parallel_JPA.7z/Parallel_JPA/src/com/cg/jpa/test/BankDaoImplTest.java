package com.cg.jpa.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.cg.jpa.dao.BankDaoImpl;
import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;
import com.cp.jpa.service.BankServiceImpl;

public class BankDaoImplTest {

	Bank bank=null;
	BankServiceImpl service= null;
	BankDaoImpl dao= null;
	@Test
	public void testAddCustomer() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		 bank.setCustName("TaraG");
		 bank.setCustAge(23);
		 bank.setEmailid("tara@gmail.com");
		 bank.setAddress("Bangalore");
		 bank.setBalance(100);
		 bank.setIdProof("444787856787");
		 bank.setCustMobNo("8985655623");
		 bank.setAccountNo(10001);
		 bank.setAccPin(6222);
		 int acc=service.addCustomer(bank);
		 System.out.println(acc);
		assertEquals(10001,acc);
		 
	}

	@Test
	public void testShowBalance() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance=service.showBalance(10001, 6222);
		assertEquals(100, balance, 0);
	}

	@Test
	public void testDepositAmount() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance= service.depositAmount(10001, 6222, 100);
		assertEquals(200, balance,0);
	}

	@Test
	public void testWithdrawAmount() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance= service.withdrawAmount(10001, 6222, 100);
		assertEquals(100, balance, 0);
	}

	@Test
	public void testFundTransfer() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance=service.FundTransfer(1029456, 3344, 10001, 100);
		System.out.println(balance);
		//Account '1029456' is already present in the DB
		System.out.println(balance);
		assertEquals(200, balance, 0);
	}

	@Test
	public void testPrintTransaction() throws BankException {
		int flag;
		bank= new Bank();
		service=new BankServiceImpl();
		List<Transaction> custList= service.printTransaction(10001);
		//System.out.println(custList);
		if(custList!=null){
			flag=1;
		}else{
			flag=0;
		}
		assertEquals("Success", 1, flag);
	}

}

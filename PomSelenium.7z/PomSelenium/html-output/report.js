$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cpagemini/trg/bdd/validhtmlform.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Latika"
    }
  ],
  "line": 3,
  "name": "validating form",
  "description": "",
  "id": "validating-form",
  "keyword": "Feature"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 6167193661,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Null username field",
  "description": "",
  "id": "validating-form;null-username-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "empty value is enterd in name text box",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.empty_value_is_enterd_in_name_text_box()"
});
formatter.result({
  "duration": 769676961,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3638572701,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2805956294,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Null city field",
  "description": "",
  "id": "validating-form;null-city-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "empty city name is entered",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.empty_city_name_is_entered()"
});
formatter.result({
  "duration": 581680699,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3588724974,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2630889304,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Null password field",
  "description": "",
  "id": "validating-form;null-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "empty password is entered",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.empty_password_is_entered()"
});
formatter.result({
  "duration": 506184867,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5809711435,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 3342321772,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "radio button not clicked",
  "description": "",
  "id": "validating-form;radio-button-not-clicked",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 26,
  "name": "either button is not clicked",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.either_button_is_not_clicked()"
});
formatter.result({
  "duration": 442149316,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 4155218556,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 3023525222,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "checkbox validation",
  "description": "",
  "id": "validating-form;checkbox-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "no checkbox is selected",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.no_checkbox_is_selected()"
});
formatter.result({
  "duration": 530164202,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3996533652,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2951644649,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "check for email",
  "description": "",
  "id": "validating-form;check-for-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "no email id entered",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.no_email_id_entered()"
});
formatter.result({
  "duration": 499194330,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5796184884,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2872989723,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "no mobile number",
  "description": "",
  "id": "validating-form;no-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "no mobile number entered",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.no_mobile_number_entered()"
});
formatter.result({
  "duration": 459037610,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3866184604,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2621596621,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "wrong mobile number",
  "description": "",
  "id": "validating-form;wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 49,
  "name": "enter wrong mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 50,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.enter_wrong_mobile_number()"
});
formatter.result({
  "duration": 589725909,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3785844911,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2582342792,
  "status": "passed"
});
formatter.scenario({
  "line": 53,
  "name": "wrong name pattern",
  "description": "",
  "id": "validating-form;wrong-name-pattern",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 54,
  "name": "wrong name is entered",
  "keyword": "When "
});
formatter.step({
  "line": 55,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.wrong_name_is_entered()"
});
formatter.result({
  "duration": 593762461,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3745896172,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2608877379,
  "status": "passed"
});
formatter.scenario({
  "line": 57,
  "name": "wrong password",
  "description": "",
  "id": "validating-form;wrong-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 58,
  "name": "wrong password is entered",
  "keyword": "When "
});
formatter.step({
  "line": 59,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.wrong_password_is_entered()"
});
formatter.result({
  "duration": 648795352,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3671967376,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2601586973,
  "status": "passed"
});
formatter.scenario({
  "line": 65,
  "name": "all empty fields",
  "description": "",
  "id": "validating-form;all-empty-fields",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 66,
  "name": "all fields are empty",
  "keyword": "When "
});
formatter.step({
  "line": 67,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.all_fields_are_empty()"
});
formatter.result({
  "duration": 307100394,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 3654450627,
  "status": "passed"
});
});
package com.cpagemini.trg.bdd2;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cpagemini.trg.bdd.HomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SteDef2 {

	
	private HomePage2 home2;
	private WebDriver wd;
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		home2= new HomePage2(wd);
		wd.get("D:\\Latika\\BDD\\Loginpage.html");
	}

	@When("^no username entered$")
	public void no_username_entered() throws Throwable {
	    home2.setUsername("");
	    home2.setButton();
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		Thread.sleep(500);
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}

	@When("^no password entered$")
	public void no_password_entered() throws Throwable {
	    home2.setUsername("aaa");
	    home2.setPassword("");
	    home2.setButton();
	}

	@When("^wrong username entered$")
	public void wrong_username_entered() throws Throwable {
	    home2.setUsername("gsg");
	    home2.setPassword("Saii3jj");
	    home2.setButton();
	    
	}

	@When("^incorrect password pattern$")
	public void incorrect_password_pattern() throws Throwable {
	    home2.setUsername("Gdd");
	    home2.setPassword("aaa");
	    home2.setButton();
	}


}

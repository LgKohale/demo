package com.cpagemini.trg.bdd2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage2 {

	 WebDriver wdriver;
		
		public HomePage2(WebDriver driver) {
			this.wdriver= driver;
			PageFactory.initElements(driver, this);
		}
		
		@FindBy(name="username")
		@CacheLookup
		WebElement username;
		
		@FindBy(name="password")
		@CacheLookup
		WebElement password;
		
		@FindBy(name="submit")
		@CacheLookup
		WebElement button;

		public WebElement getUsername() {
			return username;
		}

		public void setUsername(String n) {
			username.sendKeys(n);
		}

		public WebElement getPassword() {
			return password;
		}

		public void setPassword(String pass) {
			password.sendKeys(pass);
		}

		public WebElement getButton() {
			return button;
		}

		public void setButton() {
			button.click();
		}
		
		
}

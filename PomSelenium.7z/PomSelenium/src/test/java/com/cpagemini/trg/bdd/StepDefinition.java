package com.cpagemini.trg.bdd;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	private HomePage home;
	private WebDriver wd;
	
	@Given("^enter all the fields$")
	public void enter_all_the_fields() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		home= new HomePage(wd);
		wd.get("D:\\Latika\\BDD\\Basicform.html");
	}
	

	@Then("^error message$")
	public void error_message() throws Throwable {
		String alertMessage = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		Thread.sleep(500);
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(1000);
		wd.close();
	}

	
	
	@When("^empty value is enterd in name text box$")
	public void empty_value_is_enterd_in_name_text_box() throws Throwable {
	    home.setUsername("");
	    home.setCity("Pune");
	    home.setPassword("Pune123");
	    home.setGender("male");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(1);
	    l1.add(2);
	    home.setLanguage(l1);
	  //  home.setCountry("ind");
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	
	

	@When("^empty city name is entered$")
	public void empty_city_name_is_entered() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("");
	    home.setPassword("Pune123");
	    home.setGender("male");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(1);
	    l1.add(2);
	    home.setLanguage(l1);
	 //   home.setCountry("ind");
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}
	
	

	@When("^empty password is entered$")
	public void empty_password_is_entered() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("Pune");
	    home.setPassword("");
	    home.setGender("male");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(2);
	    home.setLanguage(l1);
	//    home.setCountry("ind");
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	
	

	@When("^either button is not clicked$")
	public void either_button_is_not_clicked() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("Pune");
	    home.setPassword("Pune123");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(1);
	    home.setLanguage(l1);
	    home.setGender("");
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}

	
	
	/*@When("^no country is selected$")
	public void no_country_is_selected() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("david44G");
	    home.setMgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("ss@view.org");
	    home.setMobile("4564587453");
	    home.setsubmit();
	    
	    
	    Scenario: country validation
	    When no country is selected
	    Then error message
	}*/


	@When("^no checkbox is selected$")
	public void no_checkbox_is_selected() throws Throwable {
		home.setUsername("Tommy");
	    home.setCity("Pune");
	    home.setPassword("Pune123");
	    home.setGender("male");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(1);
	    home.setLanguage(l1);
	    home.setEmail("pun@ggg.ord");
	    home.setMobile("8945612322");
	    home.setsubmit();
	}
	
	

	@When("^no email id entered$")
	public void no_email_id_entered() throws Throwable {
		home.setUsername("Prachi");
		home.setCity("Mumbai");
	    home.setPassword("Mumbai12");
	    home.setGender("female");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(3);
	    l1.add(2);
	    home.setLanguage(l1);
	    home.setMobile("1466677687");
	    home.setsubmit();
	}

	
	
	@When("^no mobile number entered$")
	public void no_mobile_number_entered() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("davidMu");
	    home.setGender("male");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(2);
	    home.setLanguage(l1);
	    home.setEmail("ss@view.org");
	    home.setsubmit();
	}

	@When("^enter wrong mobile number$")
	public void enter_wrong_mobile_number() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("davidmum");
	    home.setGender("female");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(3);
	    l1.add(2);
	    home.setLanguage(l1);
	    home.setEmail("ss@view.org");
	    home.setMobile("8945612352555");
	    home.setsubmit();
	}


	
	//wrong name pattern
	@When("^wrong name is entered$")
	public void wrong_name_is_entered() throws Throwable {
		home.setUsername("avid");
		home.setCity("Mumbai");
	    home.setPassword("pune123");
	    home.setGender("female");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(1);
	    home.setLanguage(l1);
	    home.setEmail("ss@view.org");
	    home.setMobile("4564587453");
	    home.setsubmit();
	}
	
	
	
	@When("^wrong password is entered$")
	public void wrong_password_is_entered() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("david");
	    home.setGender("male");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(3);
	    l1.add(1);
	    home.setLanguage(l1);
	    home.setEmail("ss@view.org");
	    home.setMobile("4564587453");
	    home.setsubmit();
	}

	
	
	/*@When("^email id is not proper$")
	public void email_id_is_not_proper() throws Throwable {
		home.setUsername("David");
		home.setCity("Mumbai");
	    home.setPassword("david44G");
	    home.setMgender();
	    home.setEnglish();
	    home.setTamil();
	    home.setEmail("ssiew.org");
	    home.setMobile("4564587453");
	    home.setsubmit();
	    
	    Scenario: wrong email format
	    When email id is not proper
	    Then error message
	}*/

	@When("^all fields are empty$")
	public void all_fields_are_empty() throws Throwable {
		home.setUsername("");
		home.setCity("");
	    home.setPassword("");
	    home.setGender("");
	    home.setEmail("");
	    List<Integer> l1= new ArrayList<>();
	    l1.add(0);
	    home.setLanguage(l1);
	    home.setMobile("");
	    home.setsubmit();
	}
}


package com.cg.Selenium_project;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class valid {

	String name= null;
	@Given("^user enters name$")
	public void user_enters_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		WebDriver wb= new ChromeDriver();
		wb.get("D:\\Latika\\latika2\\JEE_Spring\\Selenium_project\\src\\test\\java\\com\\cg\\Selenium_project\\front_page.html"); 
		
		WebElement element= wb.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input"));
		element.sendKeys("Latika");
		name=element.getText();
		System.out.println(name);
	}

	@When("^validate user entered name$")
	public void validate_user_entered_name() throws Throwable {
	   boolean valid=false;
		String regex="^[a-zA-Z ]+$";
		if(name.matches(regex)){
			System.out.println("Valid name");
			valid= true;
		}
		assertTrue(valid);
	}

	@Then("^ask for last name$")
	public void ask_for_last_name() throws Throwable {
	  
	   System.out.println("Enter last name");
	}


}

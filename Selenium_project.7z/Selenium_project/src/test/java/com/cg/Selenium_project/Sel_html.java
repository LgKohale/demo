package com.cg.Selenium_project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Sel_html {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		WebDriver wb= new ChromeDriver();
		wb.get("D:\\Latika\\latika2\\JEE_Spring\\Selenium_html\\src\\main\\java\\com\\cg\\trg\\Selenium_html\\front_page.html");
		
		
		
		
		
		
		
		
		/*WebElement element= wb.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input"));
		element.sendKeys("Latika");
		
		WebElement element1= wb.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input"));
		element1.sendKeys("Kohale");
		
		WebElement ele1= wb.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/select"));
		Select dropdown= new Select(ele1);
		dropdown.selectByVisibleText("Pune");
		
		WebElement ele2= wb.findElement(By.name("female"));
		ele2.click();
		
		
		WebElement ele3= wb.findElement(By.name("java"));
		ele3.click();
		
		WebElement button= wb.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td/input"));
		button.click();
		
		wb.navigate().refresh();*/
		
	}
}

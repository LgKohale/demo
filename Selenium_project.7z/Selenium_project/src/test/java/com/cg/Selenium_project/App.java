package com.cg.Selenium_project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
 

public class App {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		WebDriver wb= new ChromeDriver();
		/*wb.get("https://www.google.com");*/
		/*String s=wb.getCurrentUrl();
		System.out.println(s);  //op=https://www.google.com/
		s=wb.getTitle();
		System.out.println(s); //op=Google
		s=wb.getPageSource();
				System.out.println(s);
		//wb.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS); //waits for time seconds
		wb.navigate().refresh();
		//wb.close();  //closes only that browser after executing all the operations opened by get()
		//wb.quit();   //closes all the browsers manually opened or by get()
*/		
		
		/*WebElement ele= wb.findElement(By.name("q"));
		ele.sendKeys("selenium");
		WebElement ele1= wb.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]"));
		ele1.click();
		wb.navigate().forward();*/
		
		/*WebElement ele= wb.findElement(By.name("q"));
		ele.sendKeys("India");
		WebElement ele1= wb.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]"));
		ele1.click();
		wb.navigate().forward();*/
		
		

		
		
		
	}
}

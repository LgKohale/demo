package com.cg.Selenium_project;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin={"usage","html:Html/html1p"},features= {"classpath:feat"}, glue="com.cg.Selenium_project")
public class Test {

}

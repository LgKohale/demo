$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("feat/valid.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Latika"
    }
  ],
  "line": 3,
  "name": "validate login page",
  "description": "",
  "id": "validate-login-page",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "To validate first name",
  "description": "",
  "id": "validate-login-page;to-validate-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "user enters name",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "validate user entered name",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "ask for last name",
  "keyword": "Then "
});
formatter.match({
  "location": "valid.user_enters_name()"
});
formatter.result({
  "duration": 5605580862,
  "status": "passed"
});
formatter.match({
  "location": "valid.validate_user_entered_name()"
});
formatter.result({
  "duration": 1783631,
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.cg.Selenium_project.valid.validate_user_entered_name(valid.java:39)\r\n\tat ✽.When validate user entered name(feat/valid.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "valid.ask_for_last_name()"
});
formatter.result({
  "status": "skipped"
});
});
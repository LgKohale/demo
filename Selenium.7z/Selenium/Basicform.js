
function validate() {
	var x= document.forms["form1"]["userName"].value;
	if(x=="") {
		alert("please fill username..");
		
	}
	
	var city= document.forms["form1"]["city"].value;
	if(city==""){
		alert("please enter city name");
		
	}
	var pass= document.forms["form1"]["password"].value;
	if(pass==""){
		alert("enter password..");
		
	}
	
	if(!(document.getElementById('male').checked) && !(document.getElementById('female').checked)){
		alert("Please select Gender: Male or Female");
		
	}
	else if((document.getElementById('male').checked) && (document.getElementById('female').checked)){
		alert("Select only one gender button");
		
	}
	if(!(document.getElementById('eng').checked) && !(document.getElementById('tel').checked) &&
					!(document.getElementById('tam').checked)){
						alert("Select atleast one Language..");
						
					}
	
	var mob= document.forms["form1"]["mobile"].value;
	if(mob==""){
		alert("Please enter mobile number..");
		
	}
	
	var mail=document.forms["form1"]["email"].value;
	if(mail==""){
		alert("Enter email id..");
		
	}
	
	var mob1= document.forms["form1"]["mobile"].value;
	var len= mob1.length;
	if(len > 10){
		alert("Enter correct mobile number..");
		
		
	}

	var name = /^[A-Z][a-z]+$/
	if (name.test(document.form1.userName.value) == false){
		alert("Enter name in Init-Caps(ex-Tom)");
		
		} 
	
	var passx= /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
	var pass= document.forms["form1"]["password"].value;
	if(passx.test(pass)== false){
		alert("Password should be of min 6 letters with atleast 1 Uppsercase,lowercase and digit");
		
	}
	
	var emailx= /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var eid=document.forms["form1"]["email"].value; 
	if(emailx.test(eid)==false){
		alert("Enter email in valid format..");
		
	}
		
	var opt= document.forms["form1"]["country"].value;
	if(opt=="select"){
		alert("Select any country..");
	}
}


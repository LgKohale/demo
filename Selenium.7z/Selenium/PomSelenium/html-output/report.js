$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cpagemini/trg/bdd/validhtmlform.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Latika"
    }
  ],
  "line": 3,
  "name": "validating form",
  "description": "",
  "id": "validating-form",
  "keyword": "Feature"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 3214259959,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Null username field",
  "description": "",
  "id": "validating-form;null-username-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "empty value is enterd in name text box",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.empty_value_is_enterd_in_name_text_box()"
});
formatter.result({
  "duration": 596633060,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5551531056,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2776981191,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Null city field",
  "description": "",
  "id": "validating-form;null-city-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "empty city name is entered",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.empty_city_name_is_entered()"
});
formatter.result({
  "duration": 593446123,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5559519117,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2856656287,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Null password field",
  "description": "",
  "id": "validating-form;null-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "empty password is entered",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.empty_password_is_entered()"
});
formatter.result({
  "duration": 581655805,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5547927752,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2673919081,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "radio button not clicked",
  "description": "",
  "id": "validating-form;radio-button-not-clicked",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 26,
  "name": "either button is not clicked",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.either_button_is_not_clicked()"
});
formatter.result({
  "duration": 565751469,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5549650643,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2769747921,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "checkbox validation",
  "description": "",
  "id": "validating-form;checkbox-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "no checkbox is selected",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.no_checkbox_is_selected()"
});
formatter.result({
  "duration": 460801152,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5536493088,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2743475883,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "check for email",
  "description": "",
  "id": "validating-form;check-for-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "no email id entered",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.no_email_id_entered()"
});
formatter.result({
  "duration": 460006982,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5552559047,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2729863403,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "no mobile number",
  "description": "",
  "id": "validating-form;no-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "no mobile number entered",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.no_mobile_number_entered()"
});
formatter.result({
  "duration": 551640582,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5549097267,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2711046562,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "wrong mobile number",
  "description": "",
  "id": "validating-form;wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 49,
  "name": "enter wrong mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 50,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.enter_wrong_mobile_number()"
});
formatter.result({
  "duration": 608223605,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5558382008,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2715425167,
  "status": "passed"
});
formatter.scenario({
  "line": 53,
  "name": "wrong name pattern",
  "description": "",
  "id": "validating-form;wrong-name-pattern",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 54,
  "name": "wrong name is entered",
  "keyword": "When "
});
formatter.step({
  "line": 55,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.wrong_name_is_entered()"
});
formatter.result({
  "duration": 601854241,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5554135902,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2664294273,
  "status": "passed"
});
formatter.scenario({
  "line": 57,
  "name": "wrong password",
  "description": "",
  "id": "validating-form;wrong-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 58,
  "name": "wrong password is entered",
  "keyword": "When "
});
formatter.step({
  "line": 59,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.wrong_password_is_entered()"
});
formatter.result({
  "duration": 625092349,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5557645267,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "to open browser",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "enter all the fields",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.enter_all_the_fields()"
});
formatter.result({
  "duration": 2682823146,
  "status": "passed"
});
formatter.scenario({
  "line": 65,
  "name": "all empty fields",
  "description": "",
  "id": "validating-form;all-empty-fields",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 66,
  "name": "all fields are empty",
  "keyword": "When "
});
formatter.step({
  "line": 67,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.all_fields_are_empty()"
});
formatter.result({
  "duration": 293119553,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.error_message()"
});
formatter.result({
  "duration": 5541481268,
  "status": "passed"
});
});
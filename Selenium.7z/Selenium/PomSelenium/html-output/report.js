$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cpagemini/trg/bdd2/loginvalid.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: ##"
    }
  ],
  "line": 3,
  "name": "Validate Login page",
  "description": "",
  "id": "validate-login-page",
  "keyword": "Feature"
});
formatter.background({
  "line": 5,
  "name": "User is on Login page for login",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "SteDef2.user_is_on_login_page()"
});
formatter.result({
  "duration": 3320423684,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "no usernmae entered",
  "description": "",
  "id": "validate-login-page;no-usernmae-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "no username entered",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "display error message",
  "keyword": "Then "
});
formatter.match({
  "location": "SteDef2.no_username_entered()"
});
formatter.result({
  "duration": 168146370,
  "status": "passed"
});
formatter.match({
  "location": "SteDef2.display_error_message()"
});
formatter.result({
  "duration": 3643070717,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "User is on Login page for login",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "SteDef2.user_is_on_login_page()"
});
formatter.result({
  "duration": 2744132633,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "no password entered",
  "description": "",
  "id": "validate-login-page;no-password-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "no password entered",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "display error message",
  "keyword": "Then "
});
formatter.match({
  "location": "SteDef2.no_password_entered()"
});
formatter.result({
  "duration": 249328585,
  "status": "passed"
});
formatter.match({
  "location": "SteDef2.display_error_message()"
});
formatter.result({
  "duration": 3686404708,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "User is on Login page for login",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "SteDef2.user_is_on_login_page()"
});
formatter.result({
  "duration": 2747905765,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "username not matching",
  "description": "",
  "id": "validate-login-page;username-not-matching",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "wrong username entered",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "display error message",
  "keyword": "Then "
});
formatter.match({
  "location": "SteDef2.wrong_username_entered()"
});
formatter.result({
  "duration": 252030653,
  "status": "passed"
});
formatter.match({
  "location": "SteDef2.display_error_message()"
});
formatter.result({
  "duration": 13020954,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no alert open\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T520\u0027, ip: \u002710.219.34.236\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.38.552522 (437e6fbedfa876..., userDataDir: C:\\Users\\lkohale\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 72a1bc3c6a7fd4b79d893faed81bff8f\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cpagemini.trg.bdd2.SteDef2.display_error_message(SteDef2.java:39)\r\n\tat ✽.Then display error message(com/cpagemini/trg/bdd2/loginvalid.feature:18)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 5,
  "name": "User is on Login page for login",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on login page",
  "keyword": "Given "
});
formatter.match({
  "location": "SteDef2.user_is_on_login_page()"
});
formatter.result({
  "duration": 2912222394,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "incorrect password pattern",
  "description": "",
  "id": "validate-login-page;incorrect-password-pattern",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "incorrect password pattern",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "display error message",
  "keyword": "Then "
});
formatter.match({
  "location": "SteDef2.incorrect_password_pattern()"
});
formatter.result({
  "duration": 293227849,
  "status": "passed"
});
formatter.match({
  "location": "SteDef2.display_error_message()"
});
formatter.result({
  "duration": 2859589,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no alert open\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T520\u0027, ip: \u002710.219.34.236\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.38.552522 (437e6fbedfa876..., userDataDir: C:\\Users\\lkohale\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 84e4be72abc377c7ca2e593d655ba8bf\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cpagemini.trg.bdd2.SteDef2.display_error_message(SteDef2.java:39)\r\n\tat ✽.Then display error message(com/cpagemini/trg/bdd2/loginvalid.feature:22)\r\n",
  "status": "failed"
});
});
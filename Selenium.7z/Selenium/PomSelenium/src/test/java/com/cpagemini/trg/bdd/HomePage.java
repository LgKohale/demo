package com.cpagemini.trg.bdd;


import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	 WebDriver wdriver;
	
	public HomePage(WebDriver driver) {
		this.wdriver= driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement username;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(name="gender")
	@CacheLookup
	List<WebElement> gender;

	@FindBy(name="lang")
	@CacheLookup
	List<WebElement> language;
	
	@FindBy(xpath="/html/body/center/form/input[12]")
	@CacheLookup
	WebElement email;

	@FindBy(name="mobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(xpath="/html/body/center/form/select")
	@CacheLookup
	WebElement country;

	@FindBy(xpath="/html/body/center/form/button")
	@CacheLookup
	WebElement submit;
	
	

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String name) {
		username.sendKeys(name);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city1) {
		city.sendKeys(city1);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String pass) {
		password.sendKeys(pass);
	}

	public WebElement getsubmit() {
		return submit;
	}

	public void setsubmit() {
		submit.click();
	}


	public List<WebElement> getGender() {
		return gender;
	}

	public void setGender(String gen) {
		if(gen.equalsIgnoreCase("male"))
		{
			this.gender.get(0).click();
		}
		else if(gen.equalsIgnoreCase("female"))
		{
			this.gender.get(1).click();
		}
		else
		{
			
		}
	}

	
	public List<WebElement> getLanguage() {
		return language;
	}

	public void setLanguage(List<Integer> lang) {
			Iterator<Integer> it = lang.iterator();
			while(it.hasNext())
			{
			int a = it.next();
				if(a == 1){
					this.language.get(0).click();
				} 
				if(a == 2){
					this.language.get(1).click();
					}
				if(a == 3){
					this.language.get(2).click();
					}
				else{	}
			} 
	}
	

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String mail) {
		email.sendKeys(mail);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mob) {
		mobile.sendKeys(mob);
	}

	public WebElement getCountry() {
		return country;
	}
/*
	public void setCountry(String coun) {
		Select dropdown= new Select(country);
		dropdown.selectByValue(coun);
		
	}*/
	
	
}


package com.cpagemini.trg.bdd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sel {
/*
	System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
	wb = new ChromeDriver();
	wb.get("D:\\Latika\\BDD\\Basicform.html");
	WebElement ele1= wb.findElement(By.xpath("/html/body/center/form/input[2]"));
	String text= ele1.getText();
	
	WebElement ele2= wb.findElement(By.xpath("/html/body/center/form/input[2]"));
	String text2= ele2.getAttribute("placeholder");
	
	System.out.println("getText(): "+text);
	System.out.println("getAttribute() :"+text2);*/
}

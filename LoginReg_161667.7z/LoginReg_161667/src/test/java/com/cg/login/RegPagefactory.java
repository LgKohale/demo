package com.cg.login;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegPagefactory {


	WebDriver driver;
	public RegPagefactory(WebDriver webdriver) {
		this.driver = webdriver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="graduation")
	@CacheLookup
	WebElement grad;
	
	@FindBy(name="percentage")
	@CacheLookup
	WebElement perct;

	@FindBy(name="passingYear")
	@CacheLookup
	WebElement pYear;

	@FindBy(name="projectName")
	@CacheLookup
	WebElement prName;

	@FindBy(name="technologies")
	@CacheLookup
	List<WebElement> tech;
	
	@FindBy(name="otherTechnologies")
	@CacheLookup
	WebElement oTech;
	
	@FindBy(xpath="//*[@id=\"btnRegister\"]")
	@CacheLookup
	WebElement button;
	
	
	public WebElement getGrad() {
		return grad;
	}

	public void setGrad(String gd) {
		Select dd= new Select(grad);
		dd.selectByVisibleText(gd);
		
	}

	public WebElement getPerct() {
		return perct;
	}

	public void setPerct(String pr) {
		perct.sendKeys(pr);
	}

	public WebElement getpYear() {
		return pYear;
	}

	public void setpYear(String year) {
		pYear.sendKeys(year);
	}

	public WebElement getPrName() {
		return prName;
	}

	public void setPrName(String pro) {
		prName.sendKeys(pro);
	}

	public List<WebElement> getTech() {
		return tech;
	}

	public void setTech(List<Integer> tg) {
		Iterator<Integer> it = tg.iterator();
		while(it.hasNext())
		{
		int a = it.next();
			if(a == 1){
				this.tech.get(0).click();
			} 
			if(a == 2){
				this.tech.get(1).click();
				}
			if(a == 3){
				this.tech.get(2).click();
				}
			if(a==4) {
				this.tech.get(3).click();
				//setoTech(oTech);
			}
			else{
				
			}
		} 
	}

	public WebElement getoTech() {
		return oTech;
	}

	public void setoTech(String oo) {
		WebElement other= driver.findElement(By.xpath("//*[@id=\"cbTechnologies\"]"));
		Boolean select = other.isSelected();
		if(select) {
			oTech.sendKeys(oo);
		}
		
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
	
	
}

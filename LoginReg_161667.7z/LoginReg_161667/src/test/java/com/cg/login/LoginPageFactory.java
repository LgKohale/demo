package com.cg.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LoginPageFactory {

	WebDriver driver;
	public LoginPageFactory(WebDriver webdriver) {
		this.driver = webdriver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement fname;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lname;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(name="address1")
	@CacheLookup
	WebElement add1;
	
	@FindBy(name="address2")
	@CacheLookup
	WebElement add2;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[11]/td/a")
	@CacheLookup
	WebElement next;
	
	//Getters
	public WebElement getFname() {
		return fname;
	}

	public WebElement getLname() {
		return lname;
	}
	
	public WebElement getEmail() {
		return email;
	}
	
	public WebElement getPhone() {
		return phone;
	}

	public WebElement getAdd1() {
		return add1;
	}
	
	public WebElement getAdd2() {
		return add2;
	}
	
	public WebElement getCity() {
		return city;
	}

	public WebElement getState() {
		return state;
	}
	
	public WebElement getNext() {
		return next;
	}


	//Setters
	public void setFname(String fn) {
		fname.sendKeys(fn);
	}

	

	public void setLname(String ln) {
		lname.sendKeys(ln);
	}

	

	public void setEmail(String mail) {
		email.sendKeys(mail);
	}

	
	public void setPhone(String ph) {
		phone.sendKeys(ph);
	}

	

	public void setAdd1(String ad1) {
		add1.sendKeys(ad1);
	}

	

	public void setAdd2(String ad2) {
		add2.sendKeys(ad2);
	}


	public void setCity(String ct) {
		Select cityd= new Select(city);
		cityd.selectByVisibleText(ct);
	}


	public void setState(String st) {
		Select std= new Select(state);
		std.selectByVisibleText(st);
	}
	

	public void setNext() {
		next.click();
	}
	
}

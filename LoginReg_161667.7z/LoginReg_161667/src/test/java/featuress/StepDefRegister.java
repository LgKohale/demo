package featuress;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.login.RegPagefactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefRegister {

	private WebDriver wd;
	private RegPagefactory reg;
	
	@Given("^User is on register page$")
	public void user_is_on_register_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		reg= new RegPagefactory(wd);
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wd.get("C:\\Users\\lkohale\\Desktop\\SET03\\WebPages\\EducationalDetails.html");
	}

	@Then("^check for title of register page$")
	public void check_for_title_of_register_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String heading= wd.getTitle();
	    if(heading.contentEquals("Educational Details")) {
	    	System.out.println("**Title Matched**");
	    }else {
	    	System.out.println("**Title not Matched");
	    }
	    Thread.sleep(1000);
	    wd.close();
	}

	@Then("^check for heading of register page$")
	public void check_for_heading_of_register_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String heading= wd.findElement(By.xpath("/html/body/h4")).getText();
	    if(heading.contentEquals("Step 2: Educational Details")) {
	    	System.out.println("**Heading Matched**");
	    }else {
	    	System.out.println("**Heading not Matched");
	    }
	    Thread.sleep(1000);
	    wd.close();
	}

	@When("^no graduation option selected$")
	public void no_graduation_option_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    reg.setGrad("Select graduation");
	    reg.setButton();
	}

	@Then("^display alert for graduation$")
	public void display_alert_for_graduation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}

	@When("^no percentage is entered$")
	public void no_percentage_is_entered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    reg.setGrad("BE");
	    reg.setPerct("");
	    reg.setButton();
	}

	@Then("^alert for no percentage$")
	public void alert_for_no_percentage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}

	@When("^no passing year entered$")
	public void no_passing_year_entered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   reg.setGrad("BE");
	   reg.setPerct("81.2");
	   reg.setpYear("");
	   reg.setButton();
	}

	@Then("^display alert for no year$")
	public void display_alert_for_no_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}

	@When("^no project name entered$")
	public void no_project_name_entered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reg.setGrad("BE");
		   reg.setPerct("81.2");
		   reg.setpYear("2017");
		   reg.setPrName("");
		   reg.setButton();
	}

	@Then("^display alert for no project$")
	public void display_alert_for_no_project() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}

	@When("^no technologies selected$")
	public void no_technologies_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reg.setGrad("BE");
		   reg.setPerct("81.2");
		   reg.setpYear("2017");
		   reg.setPrName("ChatBot For college");
		   List<Integer> l1= new ArrayList<>();
		   l1.add(8);
		   reg.setTech(l1);
		   reg.setButton();
	}

	@Then("^display alert for technologies$")
	public void display_alert_for_technologies() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}

	@When("^other option is selected for technology and field is empty$")
	public void other_option_is_selected_for_technology_and_field_is_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reg.setGrad("BE");
		   reg.setPerct("81.2");
		   reg.setpYear("2017");
		   reg.setPrName("ChatBot For college");
		   List<Integer> l1= new ArrayList<>();
		   l1.add(4);
		   reg.setTech(l1);
		   reg.setoTech("");
		   reg.setButton();
	}

	@Then("^alert for other technology$")
	public void alert_for_other_technology() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}

	@When("^valid details are entered for registration$")
	public void valid_details_are_entered_for_registration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reg.setGrad("BE");
		   reg.setPerct("81.2");
		   reg.setpYear("2017");
		   reg.setPrName("ChatBot For college");
		   List<Integer> l1= new ArrayList<>();
		   l1.add(2);
		   reg.setTech(l1);
		   reg.setButton();
	}

	@Then("^display the alert box$")
	public void display_the_alert_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+Message);
		Thread.sleep(500);
		wd.close();
	}


}

package featuress;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.login.LoginPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {

	private WebDriver wd;
	private LoginPageFactory log;
	
	
	@Given("^user is on login webpage$")
	public void user_is_on_login_webpage() throws Throwable {
	    
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver\\chromedriver.exe");
		wd = new ChromeDriver();
		log= new LoginPageFactory(wd);
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wd.get("C:\\Users\\lkohale\\Desktop\\SET03\\WebPages\\PersonalDetails.html");
	}

	
	@Then("^check for title of login page$")
	public void check_for_title_of_login_page() throws Throwable {
	    
		String heading= wd.getTitle();
	    if(heading.contentEquals("Personal Details")) {
	    	System.out.println("**Title Matched**");
	    }else {
	    	System.out.println("**Title not Matched");
	    }
	    Thread.sleep(1000);
	    wd.close();
	}

	@Then("^check for page heading$")
	public void check_for_page_heading() throws Throwable {
	    
		String heading= wd.findElement(By.xpath("/html/body/h4")).getText();
	    if(heading.contentEquals("Step 1: Personal Details")) {
	    	System.out.println("**Heading Matched**");
	    }else {
	    	System.out.println("**Heading not Matched");
	    }
	    Thread.sleep(1000);
	    wd.close();
	}


	@When("^firstname is blank$")
	public void firstname_is_blank() throws Throwable {
	    
	    log.setFname("");
	    Thread.sleep(1000);
	    log.setNext();
	    System.out.println("Please enter first name");
	}
	
	
	@When("^lastname is blank$")
	public void lastname_is_blank() throws Throwable {
		log.setFname("Smith");
		log.setLname("");
	    Thread.sleep(1000);
	    log.setNext();
	    System.out.println("Please enter last name");
	}

	@When("^email is blank$")
	public void email_is_blank() throws Throwable {
	   
		log.setFname("Smith");
		log.setLname("Tie");
	    log.setEmail("");
	    Thread.sleep(1000);
	    log.setNext();
	    System.out.println("Enter email id");
	}

	@When("^email is invalid$")
	public void email_is_invalid() throws Throwable {
	    
		log.setFname("Smith");
		log.setLname("Tie");
	    log.setEmail("ss@bbbb");
	    Thread.sleep(1000);
	    log.setNext();
	    System.out.println("Please enter the Email");
	}

	@When("^contactNo is blank$")
	public void contactno_is_blank() throws Throwable {
	    
		log.setFname("Smith");
		log.setLname("Tie");
		log.setEmail("smi@yahoo.com");
	   log.setPhone("");
	   Thread.sleep(1000);
	   log.setNext();
	   System.out.println("Please enter Contact No.");
	}

	@When("^contactNo is wrong$")
	public void contactno_is_wrong() throws Throwable {
	    
		log.setFname("Smith");
		log.setLname("Tie");
		log.setEmail("smi@yahoo.com");
		 log.setPhone("1234567895");
		 Thread.sleep(1000);
		   log.setNext();
		   System.out.println("Please enter valid Contact No.");
	}

	@When("^addressLineone is blank$")
	public void addresslineone_is_blank() throws Throwable {
	    
		log.setFname("Smith");
		log.setLname("Tie");
		log.setEmail("smi@yahoo.com");
		log.setPhone("8945652100");
	   log.setAdd1("");
	   Thread.sleep(1000);
	   log.setNext();
	   System.out.println("Please enter address 1");
	}

	@When("^addressLinetwo is blank$")
	public void addresslinetwo_is_blank() throws Throwable {
	   
		log.setFname("Smith");
		log.setLname("Tie");
		log.setEmail("smi@yahoo.com");
		log.setPhone("8945652100");
		log.setAdd1("Imperial Towers");
	   log.setAdd2("");
	   Thread.sleep(1000);
	   log.setNext();
	   System.out.println("Please enter address 2");
	}
	
	@When("^city not selected$")
	public void city_not_selected() throws Throwable {
	   
		log.setFname("Smith");
		log.setLname("Tie");
		log.setEmail("smi@yahoo.com");
		log.setPhone("8945652100");
		log.setAdd1("Imperial Towers");
	   log.setAdd2("Flat 06");
	   log.setCity("Select City");
	   Thread.sleep(1000);
	   log.setNext();
	   System.out.println("Please select city");
	}

	@When("^state not selected$")
	public void state_not_selected() throws Throwable {
	    
		log.setFname("Smith");
		log.setLname("Tie");
		log.setEmail("smi@yahoo.com");
		log.setPhone("8945652100");
		log.setAdd1("Imperial Towers");
	   log.setAdd2("Flat 06");
	   log.setCity("Pune");
	   log.setState("Select State");
	   Thread.sleep(1000);
	   log.setNext();
	   System.out.println("Please select state");
	}

	@When("^user enter all details$")
	public void user_enter_all_details() throws Throwable {
	  
	    log.setFname("Smith");
	    log.setLname("Tie");
	    log.setEmail("smit@yahoo.com");
	    log.setPhone("7894561205");
	    log.setAdd1("Imperial Towers");
	    log.setAdd2("Flat 06");
	    log.setCity("Pune");
	    log.setState("Maharashtra");
	    Thread.sleep(1000);
	    log.setNext();
	}

	@Then("^navigate to education page$")
	public void navigate_to_education_page() throws Throwable {
	   
		wd.switchTo().alert().accept();
	    wd.navigate().to("C:\\Users\\lkohale\\Desktop\\SET03\\WebPages\\EducationalDetails.html");
	    Thread.sleep(1000);
	    String heading= wd.getTitle();
	    if(heading.contentEquals("Educational Details")) {
	    	System.out.println("**Page Verified**");
	    }else {
	    	System.out.println("**Page not Verified");
	    }
	    Thread.sleep(1000);
	    wd.close();
	}
	
	@Then("^display alert for firstname$")
	public void display_alert_for_firstname() throws Throwable {
	  
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}


	@Then("^display alert for lastname$")
	public void display_alert_for_lastname() throws Throwable {
	    
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}


	
	@Then("^display alert for no email id$")
	public void display_alert_for_no_email_id() throws Throwable {
	    
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}
	
	@Then("^display alert for invalid email id$")
	public void display_alert_for_invalid_email_id() throws Throwable {
	   
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}

	@Then("^display alert for no contact$")
	public void display_alert_for_no_contact() throws Throwable {
	    
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}

	@Then("^display alert for wrong contact$")
	public void display_alert_for_wrong_contact() throws Throwable {
	    
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}
	@Then("^display alert for no address(\\d+)$")
	public void display_alert_for_no_address(int arg1) throws Throwable {
	    
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}

	@Then("^display alert for no city$")
	public void display_alert_for_no_city() throws Throwable {
	   
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}

	@Then("^display for no state$")
	public void display_for_no_state() throws Throwable {
	    
		String message = wd.switchTo().alert().getText();
		Thread.sleep(2000);
		wd.switchTo().alert().accept();
		System.out.println("alert: "+message);
		Thread.sleep(500);
		wd.close();
	}



	
}

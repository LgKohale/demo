package featuress;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","html:html-output"}, tags= {"@login"})
public class TestRun1 {

}

package com.capgemini.trg.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/helloc")
public class HelloController {
	
	@RequestMapping(value="/hello" ,method=RequestMethod.GET)  //requestMapping and view name shud be same
	public String sayHello(Model model) {
		String message= "Hii! Welcome to Spring Mvc Web Application" ;
		model.addAttribute("message", message);
		return "hello";
	}
	
	@RequestMapping(value="greet")
	public ModelAndView sayGreetings() {
		/*tring message= "Hii! Welcome to Spring Mvc Web Application.." ;
		ModelAndView mav= new ModelAndView();
		mav.addObject("greeting","Good Morning");
		mav.addObject("message",message);
		mav.setViewName("greet");
		return mav;*/
		
		return new ModelAndView("greet","greeting","good Morning!!");  //(view, attribute, attribute value)
		
	}
}


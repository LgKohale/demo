package com.capgemini.trg.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/loginc")
public class LoginController {
	@RequestMapping(value="/verify", method=RequestMethod.GET)
	public ModelAndView verifyUser(@RequestParam("username")String username, @RequestParam("password")String password ) {
		System.out.println(username+","+password);
		String status="";
		if(!username.equals(password)){
			status="Hi " +username+" ,Welcome to My Application";
		}else{
			status="Hello,"+username+" is invalid username.";
		}
		return new ModelAndView("status","status",status);
	}

	
}
